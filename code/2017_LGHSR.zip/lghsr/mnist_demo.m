% LGHSR example for mnist

load('mnist_split.mat');
load('anchor_300.mat');

[n,dim] = size(traindata);
tn = size(testdata,1);
m = 300; %number of anchors, I simply fix this parameter 
s = 3;   %number of nearest anchors, please tune this parameter on different datasets
r = [12 16,24,32 48,64,128];



ham2_pre1 = zeros(1,length(r));
for i = 1:length(r)
    tic;
    [Y, W, F, Z, sigma] = raw_sh(traindata, anchor, r(i), s,0);
    tY = OneLayerAGH_Test(testdata, anchor, W, s, sigma);
    clear W;
    toc;
    % compute hamming distance
    B = compactbit(Y);
    tB = compactbit(tY);
    clear Y;
    clear tY;
    HamDis = hammingDist(B,tB); 
    
    distance_matrix  = HamDis';
    test_true_label  = testgnd;
    train_true_label = traingnd;
    map;
    hashingBall;
end    



    
    

