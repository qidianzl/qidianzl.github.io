
%distance_matrix  query*train_sample
%test_true_label  
%train_true_label

%distance_matrix = Dhamm;
test_true_label  =testgnd;
train_true_label = traingnd;

disp('computing MAP...');
sum_average_precision = zeros(10,1);
for item = 1:size(distance_matrix,1)
	%disp(['processing item ', num2str(item), '...']);
	query_item = item;
	item_label = test_true_label(query_item);
	item_distance = distance_matrix(query_item,:);
	[sort_result, hamming_rank] = sort(item_distance);
	label_for_items = train_true_label == item_label;
	sum_item = sum(label_for_items);
	averge_precision = 0;
	count = 0;

	for i = 1:size(distance_matrix,2)
		if (label_for_items(hamming_rank(i)) == 1)
		count = count + 1;
		averge_precision = averge_precision + count/i;
		end
	end
	averge_precision = averge_precision/sum_item;
	sum_average_precision(item_label) = sum_average_precision(item_label) + averge_precision;
end
map_result = sum(sum_average_precision)/length(test_true_label);
disp(['map is ', num2str(map_result)]);