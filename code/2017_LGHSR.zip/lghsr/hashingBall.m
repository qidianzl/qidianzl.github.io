%distance_matrix
%test_true_label
%train_true_label


%distance_matrix
HamDis = uint16(distance_matrix);

test_num = size(distance_matrix,1);
recall = zeros(1,test_num);
f_measure = zeros(1,test_num);
pre = zeros(1,test_num);
for item = 1:test_num
    query_item = item;
	item_distance = distance_matrix(query_item,:);

	list = find(item_distance <= 2);
	ln_pre = length(list);
	
	item_label = test_true_label(query_item);
	
	label_for_items = train_true_label == item_label;
	ln_recall = sum(label_for_items);

	if ln_pre == 0
		pre(query_item)    = 0;%fail to find any neighbors
	else
		pre(query_item) = length(find(train_true_label(list) == item_label))/ln_pre;
	end
	recall(query_item) = length(find(train_true_label(list) == item_label))/ln_recall;
end
ham2_pre1 = mean(pre,2)
ham2_recall1 = mean(recall,2)
disp(['f-measure is ', num2str(2*ham2_pre1*ham2_recall1/(ham2_pre1+ham2_recall1))])
